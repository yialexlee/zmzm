import requests
import json

url = 'https://www.jisilu.cn/data/new_stock/apply/?___jsl=LST___t=1611728204637'
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/87.0.4280.141 Safari/537.36',
    'host': 'www.jisilu.cn'}
data = {
    'market[]': 'shmb',
    'market[]': 'shkc',
    'market[]': 'szmb',
    'market[]': 'szzx',
    'market[]': 'szcy',
    'market[]': 'sbjx',
    'rp': '22',
    'page': '1',
    'pageSize': '100'}

response = requests.post(url, data=data, headers=headers)
print(response.status_code)
print(response.content.decode('utf-8'))

#每次获取到的都是page1，我觉得是没有cookie的原因